/** Public interface to boats feature */
export * from './store/boat.model';
export * from './store/boats.query';
export * from './store/boats.service';
