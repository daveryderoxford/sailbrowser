/**  */

import { Fleet } from "./fleet";
import { Race } from "./race";

interface raceDay {
  races: Race[];

}

interface startData {

  
}



interface start {
  prepFlagName: string;
  fleet: Fleet;
  order: number; 
  status: startStatus;
}