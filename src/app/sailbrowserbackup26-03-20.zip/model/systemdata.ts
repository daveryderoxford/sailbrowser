import { BoatClass } from "./boat-class";

export interface SystemData {
  defaultClasses: BoatClass[]; /** Classes of boat with their handicaps */
}
