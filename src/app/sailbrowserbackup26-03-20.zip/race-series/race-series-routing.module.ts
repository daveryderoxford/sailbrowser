import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { PendingChangesGuard } from 'app/services/pending-changes.guard';
import { RaceEditComponent } from './race-edit/race-edit.component';
import { SeriesEditComponent } from './series-edit/series-edit.component';
import { SeriesComponent } from './series/series.component';

const routes: Routes = [
  { path: '', component: SeriesComponent },
  { path: 'series', component: SeriesComponent },
  { path: 'series/edit', component: SeriesEditComponent, canDeactivate: [PendingChangesGuard] },
  { path: 'race/edit', component: RaceEditComponent },
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class RaceSeriesRoutingModule { }
