import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { ClubsQuery } from 'app/clubs/store/clubs.query';
import { Race, raceStates } from 'app/model/race';
import { assertExists } from 'app/utilities/misc';
import { RaceSeries } from '../store/race-series.model';
import { RaceSeriesQuery } from '../store/race-series.query';
import { RaceSeriesService } from '../store/race-series.service';

@Component({
  selector: 'app-race-edit',
  templateUrl: './race-edit.component.html',
  styleUrls: ['./race-edit.component.css']
})
export class RaceEditComponent  {

  form: FormGroup;
  series: RaceSeries | undefined;
  activeObject: Race | undefined;

  states = raceStates;

  constructor(private formBuilder: FormBuilder,
    private router: Router,
    private service: RaceSeriesService,
    private query: RaceSeriesQuery,
    private clubsQuery: ClubsQuery) {

    this.form = this.formBuilder.group({
      scheduledDate: ['', Validators.required],
      scheduledStartTime: ['', Validators.required],
      startType: ['', Validators.required],
      status: ['', Validators.required],
      isDiscardable: ['', Validators.required],
      startNumber: ['', Validators.required],
    });
  }

  ionViewWillEnter(): void {

     this.series = this.query.getActive();
     //

    if (this.activeObject) {
      this.form.patchValue(this.activeObject);
    } else {
   //   this.form.patchValue(this.createRace());
    }
  }

  canDeactivate(): boolean {
    return !this.form.dirty;
  }

  cancel() {
    this.router.navigate(['/races/series']);
  }

  save() {

    // Add race to series, re-sort the array and save update the series with the new race array

    this.form.reset();
    this.router.navigate(['/races/series']);
  }

  delete() {
    this.activeObject = assertExists(this.activeObject);

    // Delete the race from the array and update the series

    this.form.reset();
    this.router.navigate(['/races/series']);
  }

}
