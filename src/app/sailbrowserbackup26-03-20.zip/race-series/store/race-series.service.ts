import { Injectable } from '@angular/core';
import { CollectionConfig, CollectionService } from 'akita-ng-fire';
import { ClubsQuery } from 'app/clubs/store/clubs.query';
import { Race } from 'app/model/race';
import firebase from 'firebase/app';
import { createRace, createSeries, RaceSeries } from './race-series.model';
import { RaceSeriesQuery } from './race-series.query';
import { RaceSeriesState, RaceSeriesStore } from './race-series.store';

@Injectable({ providedIn: 'root' })
@CollectionConfig({ path: 'clubs/${clubId}/series' })
export class RaceSeriesService extends CollectionService<RaceSeriesState> {

  testSeries: RaceSeries = createSeries({
    id: '123abc',
    name: "Summer",
    fleet: "Fast Handicap",
    races: [
      createRace({ id: 'race1', seriesId: '123abc', scheduledDate: "2020-01-01", scheduledStartTime: '11:00:00' }),
      createRace({ id: 'race2', seriesId: '123abc', scheduledDate: "2020-01-01", scheduledStartTime: '15:00:00' }),
      createRace({ id: 'race3', seriesId: '123abc', scheduledDate: "2020-02-01", scheduledStartTime: '11:00:00' }),
      createRace({ id: 'race4', seriesId: '123abc', scheduledDate: "2020-02-01", scheduledStartTime: '15:00:00' }),
      createRace({ id: 'race5', seriesId: '123abc', scheduledDate: "2020-03-01", scheduledStartTime: '11:00:00' }),
      createRace({ id: 'race6', seriesId: '123abc', scheduledDate: "2020-03-01", scheduledStartTime: '15:00:00' }),
    ]
  });

  constructor(store: RaceSeriesStore,
    private clubQuery: ClubsQuery,
    private seriesQuery: RaceSeriesQuery) {
    super(store);

      // When the club changes clear the boats store and resync it.
    /*  this.clubQuery.selectActiveId().pipe(
        tap( () => {
          this.store?.reset();
        }
      )); */

    this.store?.add(this.testSeries);
    this.store?.setActive(this.testSeries.id);
  }

  get path() {
    const clubId = this.clubQuery.getActiveId();
    return `clubs/${clubId}/series`
  }

  /** Sets active series  */
  setActive(id: string | null) {
    this.store?.setActive(id);
  }

  /** Sets the active race on the */
  setActiveRace(id: string | null) {


  //  this.store?.update({activeRaceId: id})
  }

  /**  Adds a race to a series */
  addRace(seriesId: string, race: Partial<Race>) {

    // get series reference
    const seriesRef = this.getRef(seriesId);

    // Update array adding new element
    seriesRef.update( {races: firebase.firestore.FieldValue.arrayUnion(race)} ) ;

    // add race to races collection

   // this.update({ races:  firebase.firestore.FieldValue.arrayUnion(data)}

//  var washingtonRef = db.collection("cities").doc("DC");

//washingtonRef.update({
//  regions: firebase.firestore.FieldValue.arrayUnion("greater_virginia")
//});




  }

}
