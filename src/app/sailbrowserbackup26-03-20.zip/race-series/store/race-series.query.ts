import { Injectable } from '@angular/core';
import { QueryEntity } from '@datorama/akita';
import { RaceSeriesState, RaceSeriesStore } from './race-series.store';

@Injectable({ providedIn: 'root' })
export class RaceSeriesQuery extends QueryEntity<RaceSeriesState> {

  constructor(protected store: RaceSeriesStore) {
    super(store);
  }

}

