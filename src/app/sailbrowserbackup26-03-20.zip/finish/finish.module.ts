import { NgModule } from '@angular/core';
import { SharedModule } from '../shared/shared.module';
import { FinishRoutingModule } from './finish-routing.module';

@NgModule({
  declarations: [],
  imports: [
    SharedModule,
    FinishRoutingModule
  ]
})
export class FinishModule { }
