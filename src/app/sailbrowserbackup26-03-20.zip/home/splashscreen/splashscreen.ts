import { Component } from '@angular/core';

/*
  Splashscreen diaplayed at strtup while logging on
*/
@Component({
  templateUrl: './splashscreen.html',
})
export class SplashscreenPage {

  constructor() {

  }

}
